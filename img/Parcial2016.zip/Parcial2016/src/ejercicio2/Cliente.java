package ejercicio2;

public class Cliente {

	private Ejercicio2 ejercicio2 = new Ejercicio2();
	
	public void metodoQueRelanza() throws Exception {
		ejercicio2.buscarPersona("1");
	}

	public void metodoQueTrata() {
		try {
			ejercicio2.buscarPersona("1");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
