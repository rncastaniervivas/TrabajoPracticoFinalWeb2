package ejercicio2;

public class Ejercicio2 {
	public void buscarPersona(String dni) throws Exception{
		throw new Exception();
	}
}
