package ejercicio3;

public enum Equipo {
	ROJO, AZUL;
}
