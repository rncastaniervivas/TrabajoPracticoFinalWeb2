package ejercicio4;

public class TicketSupermercado {
	/** se inicializa el ticket con total 0 */
	public TicketSupermercado() {

	}

	/** retorna el total acumulado del ticket */
	public Double subtotal(){
		return null;
	}

	/**
	 * agrega el producto con descripcion dada al ticket segun la cantidad y
	 * precio, lanza excepcion en caso de cantidad negativa
	 */
	public void agregarItem(String producto, Integer cantidad, Double precioUnitario) throws Exception{
		
	}

	/**
	 * agrega 2 unidades del producto recibido al ticket aplicando la promocion
	 * de la segunda unidad a mitad de precio
	 */
	public void agregarItemsConPromocion2daUnidadAMitadDePrecio(String producto, Double precioUnitario){
		
	}
}
