package ejercicio4;


import org.junit.Assert;
import org.junit.Test;

public class TestTicketSupermercado {

	private TicketSupermercado ticket = new TicketSupermercado();
	
	@Test
	public void alCrearTicketDeberiaTenerSubTotalCero(){
		Assert.assertEquals(new Double("0"), ticket.subtotal());
	}
	
	@Test
	public void alAgregarItemDeberiaModificarElSubtotal() throws Exception{
		ticket.agregarItem("peras", new Integer("10"), new Double("2"));
		Assert.assertEquals(new Double("20"), ticket.subtotal());
	}
	
	@Test (expected=Exception.class)
	public void alAgregarItemConCantidadNegativaDeberiaLanzarExcepcion() throws Exception{
		ticket.agregarItem("peras", new Integer("-10"), new Double("2"));
	}
	
	@Test
	public void agregarItemConPromocionDeberiaHacerDescuento(){
		ticket.agregarItemsConPromocion2daUnidadAMitadDePrecio("televisor", new Double("20"));
		Assert.assertEquals(new Double("30"), ticket.subtotal());
	}
	
	@Test
	public void agregarItemsConPromocionySinPromocionDeberiaHacerDescuentos() throws Exception{
		ticket.agregarItemsConPromocion2daUnidadAMitadDePrecio("televisor", new Double("20"));
		ticket.agregarItem("peras", new Integer("10"), new Double("2"));
		Assert.assertEquals(new Double("50"), ticket.subtotal());
	}
}
